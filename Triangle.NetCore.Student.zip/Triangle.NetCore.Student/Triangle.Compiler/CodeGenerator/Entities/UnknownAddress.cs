using Triangle.AbstractMachine;
using Triangle.Compiler.SyntaxTrees.Vnames;

namespace Triangle.Compiler.CodeGenerator.Entities
{
    public class UnknownAddress : AddressableEntity
    {

        public UnknownAddress(int size, int level, int displacement)
            : base(size, level, displacement)
        {
        }

        //Load instructions to to push the object at the address created from the annotatedAST
        //then pop the address and retrieve the object
        public override void EncodeAssign(Emitter emitter, Frame frame, int size, Vname vname)
        {
            emitter.Emit(OpCode.LOAD, Machine.AddressSize, frame.DisplayRegister(_address), _address.Displacement);
            emitter.Emit(OpCode.STOREI, size, 0, 0);
        }

        //Push an object to the top of the stack, then use that address to fetch object and push object onto stack
        public override void EncodeFetch(Emitter emitter, Frame frame, int size, Vname vname)
        {
            emitter.Emit(OpCode.LOADI, Machine.AddressSize, frame.DisplayRegister(_address));
            emitter.Emit(OpCode.STORE, size);
        }

        //Load an address onto the top of stack
        public override void EncodeFetchAddress(Emitter emitter, Frame frame, Vname vname)
        {
            emitter.Emit(OpCode.LOAD, Machine.AddressSize, frame.DisplayRegister(_address), _address.Displacement);
        }

    }
}