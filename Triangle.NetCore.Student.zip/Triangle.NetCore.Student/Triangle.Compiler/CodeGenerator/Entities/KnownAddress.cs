using Triangle.AbstractMachine;
using Triangle.Compiler.SyntaxTrees.Vnames;

namespace Triangle.Compiler.CodeGenerator.Entities
{
    public class KnownAddress : AddressableEntity
    {

        public KnownAddress(int size, int level, int displacement)
            : base(size, level, displacement)
        {
        }

        public KnownAddress(int size, Frame frame)
             : base(size, frame)
        {
        }

        //Pops a vlaue from the top of a stack and stores it in a variable
        public override void EncodeAssign(Emitter emitter, Frame frame, int size, Vname vname)
        {
            emitter.Emit(OpCode.STORE, size, frame.DisplayRegister(Address), Address.Displacement);
        }

        //Loads the value from an address onto the stack
        public override void EncodeFetch(Emitter emitter, Frame frame, int size, Vname vname)
        {
            emitter.Emit(OpCode.LOAD, size, frame.DisplayRegister(Address), Address.Displacement);
        }

        //Load an address onto the stack
        public override void EncodeFetchAddress(Emitter emitter, Frame frame, Vname vname)
        {
            emitter.Emit(OpCode.LOADA, frame.DisplayRegister(Address), Address.Displacement);
        }
    }
}