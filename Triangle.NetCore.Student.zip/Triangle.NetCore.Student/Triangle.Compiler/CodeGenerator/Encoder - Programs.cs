using Triangle.AbstractMachine;
using Triangle.Compiler.SyntaxTrees;
using Triangle.Compiler.SyntaxTrees.Visitors;

namespace Triangle.Compiler.CodeGenerator
{
    public partial class Encoder : IProgramVisitor<Frame, Void>
    {
         public Void VisitProgram(Program ast, Frame frame)
        {
            //ast.Visit(this, Frame.Initial);
            //_emitter.Emit(OpCode.HALT);
            return ast.Command.Visit(this, frame);
        }
    }
}